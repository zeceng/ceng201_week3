/**
 * Represents the doubly linked list for the music playlist.
 * Name: Zeynep Ece ÖZASLAN
 * Student ID: 250444039
 * Date: 19.10.2026
 */

public class MusicPlaylist {

    // Private instances of the doubly linked list
    private SongNode head;
    private SongNode tail;
    private SongNode current;

    // Constructor: Initialize head, tail, and current to null at the beginning
    public MusicPlaylist() {
        this.head = null;
        this.tail = null;
        this.current = null;
    }

    // Add a song to the end of the playlist
    public void addSong(String title) {
        // Create a new SongNode with the given title
        SongNode newNode = new SongNode(title);

        // If the playlist is empty, make the new node head, tail, and current
        if (head == null) {
            head = newNode;
            tail = newNode;
            current = newNode;
        } else {
            // Otherwise, add the new node after tail and update pointers
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Remove a song from the playlist by its title
    public void removeSong(String title) {
        SongNode temp = head;

        // Search for the song in the playlist
        while (temp != null && !temp.title.equals(title)) {
            temp = temp.next;
        }

        // If the song does not exist, display a message
        if (temp == null) {
            System.out.println("The song isn't in the playlist");
            return;
        }

        System.out.println("Removed: " + temp.title);

        // If the node to be removed is the only node in the playlist
        if (head == tail) {
            head = null;
            tail = null;
            current = null;
        }
        // If the node to be removed is the head
        else if (temp == head) {
            head = head.next;
            head.prev = null;
            if (current == temp) {
                current = head;
            }
        }
        // If the node to be removed is the tail
        else if (temp == tail) {
            tail = tail.prev;
            tail.next = null;
            if (current == temp) {
                current = tail;
            }
        }
        // If the node to be removed is in the middle of the playlist
        else {
            temp.prev.next = temp.next;
            temp.next.prev = temp.prev;
            if (current == temp) {
                current = temp.next;
            }
        }
    }

    // Move to the next song in the playlist
    public void nextSong() {
        // If current is not null and current.next exists, move forward
        if (current != null && current.next != null) {
            current = current.next;
            System.out.println("Playing: " + current.title);
        } else {
            System.out.println("Already at the last song of the playlist.");
        }
    }

    // Move to the previous song in the playlist
    public void previousSong() {
        // If current is not null and current.prev exists, move backward
        if (current != null && current.prev != null) {
            current = current.prev;
            System.out.println("Playing: " + current.title);
        } else {
            System.out.println("Already at the first song of the playlist.");
        }
    }

    // Display the title of the current song
    public void displayCurrentSong() {
        if (current != null) {
            System.out.println("Current Song: " + current.title);
        } else {
            System.out.println("No song is currently playing.");
        }
    }

    // Display all songs in the playlist starting from head to tail
    public void displayPlaylist() {
        SongNode temp = head;
        while (temp != null) {
            System.out.print(temp.title + " <-> ");
            temp = temp.next;
        }
        System.out.println("END");
    }
}