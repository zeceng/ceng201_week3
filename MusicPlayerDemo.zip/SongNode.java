/**
 * Represents the doubly linked list for the music playlist.
 * Name: Zeynep Ece ÖZASLAN
 * Student ID: 250444039
 * Date: 19.10.2026
 */

public class SongNode {

    String title; // Stores the title of the song

    SongNode prev; // Reference to the previous song node
    SongNode next; // Reference to the next song node

    // Constructor to initialize the song node with a title
    public SongNode(String title) {
        this.title = title;
        this.prev = null;
        this.next = null;
    }
}