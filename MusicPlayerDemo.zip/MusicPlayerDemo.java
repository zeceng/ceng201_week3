/**
 * MusicPlayerDemo.java
 * Tests the doubly linked list playlist functionality.
 * Name: Zeynep Ece ÖZASLAN
 * Student ID: 250444039
 * Date: 19.10.2026
 */
public class MusicPlayerDemo {

    public static void main(String[] args) {

        // Create the playlist object
        MusicPlaylist playlist = new MusicPlaylist();

        // Add songs to the playlist
        playlist.addSong("Shape of You - Ed Sheeran");
        playlist.addSong("Save Me - BTS");
        playlist.addSong("Snap - Manifest");
        playlist.addSong("like JENNIE - JENNIE");

        System.out.println("=== PLAYLIST ===");
        // Display the full playlist
        playlist.displayPlaylist();

        System.out.println("\n=== CURRENT SONG PLAYING ===");
        // Display the current song playing
        playlist.displayCurrentSong();

        System.out.println("\n=== NEXT SONG TO PLAY ===");
        // Go to the next song of the playlist and display/play it
        playlist.nextSong();

        System.out.println("\n=== NEXT SONG TO PLAY ===");
        // Go to the next song of the playlist and display/play it
        playlist.nextSong();

        System.out.println("\n=== PREVIOUS SONG TO PLAY ===");
        // Go to the previous song of the playlist and display/play it
        playlist.previousSong();

        System.out.println("\n=== AFTER REMOVING Shape of You SONG ===");
        // Remove the song called "Shape of You - Ed Sheeran" from the playlist
        playlist.removeSong("Shape of You - Ed Sheeran");
        // Then display the updated Playlist
        playlist.displayPlaylist();

        System.out.println("\n=== AFTER REMOVING Snap SONG ===") ;
        // Remove the song called "Snap - Manifest" from the playlist
        playlist.removeSong("Snap - Manifest");
        // Then display the updated Playlist
        playlist.displayPlaylist();

    }
}
